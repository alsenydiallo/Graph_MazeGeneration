import java.util.ArrayList;

public interface Graph {
	public int numVerts();
	public ArrayList<Integer> adjacents(int v);
}
